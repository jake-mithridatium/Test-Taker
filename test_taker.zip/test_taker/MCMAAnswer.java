/*
 * GROUP 48
 * Mohammad Abuosbie (mabuos2)
 * Jacob McKibben(jmckib2)
 * Jacob Zaworski(jzawor2)
 * 
 * Term Project (Part 4)
 */


import java.util.*;
//import java.io.*;



public class MCMAAnswer extends MCAnswer {

	public MCMAAnswer(String t, double cis) {
		super(t, cis);
	}
	
	
	public MCMAAnswer(Scanner s) {
		super(s);
	}
	
}