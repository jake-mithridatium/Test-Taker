/*
 * GROUP 48
 * Mohammad Abuosbie (mabuos2)
 * Jacob McKibben(jmckib2)
 * Jacob Zaworski(jzawor2)
 * 
 * Term Project (Part 4)
 */


import java.util.*;
//import java.io.*;



public class MCSAAnswer extends MCAnswer {

	public MCSAAnswer(String t, double cis) {
		super(t, cis);
	}
	
	
	public MCSAAnswer(Scanner s) {
		super(s);
	}

}
